<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Minhas Indicações</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link rel="icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>" type="image/png"/>
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('assets/img/apple-icon.png')); ?>">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
    <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
  <!-- Nucleo Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/nucleo-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/nucleo-svg.css')); ?>">
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  
  
  <script src="<?php echo e(url('./node_modules/jquery')); ?>"></script> 
  <script src="<?php echo e(url('./node_modules/datatables.net')); ?>"></script>
  <!-- Material Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <!-- CSS Files -->
  <link id="pagestyle" href="<?php echo e(asset('assets/css/material-dashboard.css?v=3.0.0')); ?>" rel="stylesheet" />


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>


</head>
<body class="g-sidenav-show  bg-gray-200">

    <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">
        <div class="sidenav-header">
          <i class="fas fa-times p-3 cursor-pointer text-white opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
          <a class="navbar-brand m-0" href="#" >
            <img src="./assets/img/tecnonetz_logo.png" width="100%" class="navbar-brand-img h-100" alt="main_logo">
            
          </a>
        </div>
        <hr class="horizontal light mt-0 mb-2">
        <div class="collapse navbar-collapse  w-auto  max-height-vh-100" id="sidenav-collapse-main">
          <ul class="navbar-nav">

            
            <?php if(Auth::user()->user_type_id == 1): ?>
            <li class="nav-item">
              <a class="nav-link text-white active bg-gradient-primary" href="<?php echo e(url('/')); ?>">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                  <i class="material-icons opacity-10">dashboard</i>
                </div>
                <span class="nav-link-text ms-1">Início</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white " href="<?php echo e(url('admin.cliente.sidebar')); ?>">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                  <i class="material-icons opacity-10">face</i>
                </div>
                <span class="nav-link-text ms-1">Clientes</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white " href="<?php echo e(url('admin.profissional.sidebar')); ?>">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                  <i class="material-icons opacity-10">manage_accounts</i>
                </div>
                <span class="nav-link-text ms-1">Profissionais</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white " href="<?php echo e(url('admin.parceiro.sidebar')); ?>">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                  <i class="material-icons opacity-10">perm_identity</i>
                </div>
                <span class="nav-link-text ms-1">Parceiros</span>
              </a>
            </li>


            <li class="nav-item">
              <a class="nav-link text-white " href="<?php echo e(url('admin.perfil')); ?>">
                <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                  <i class="material-icons opacity-10">person</i>
                </div>
                <span class="nav-link-text ms-1">Minha Conta</span>
              </a>
            </li>

            <?php endif; ?>
 
            
                <?php if(Auth::user()->user_type_id == 3): ?>
                <li class="nav-item">
                  <a class="nav-link text-white active bg-gradient-primary" href="<?php echo e(url('/')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                      <i class="material-icons opacity-10">dashboard</i>
                    </div>
                    <span class="nav-link-text ms-1">Início</span>
                  </a>
                </li>

                
                <li class="nav-item">
                  <a class="nav-link text-white " href="<?php echo e(url('pro.indicar.index')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                      <i class="material-icons opacity-10">settings_ethernet</i>
                    </div>
                    <span class="nav-link-text ms-1">Indicações</span>
                  </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link text-white " href="<?php echo e(url('pro.oferta.index')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                      <i class="material-icons opacity-10">card_giftcard</i>
                    </div>
                    <span class="nav-link-text ms-1">Ofertas</span>
                  </a>
                </li>



                
                  <li class="nav-item">
                    <a class="nav-link text-white " href="<?php echo e(url('perfil')); ?>">
                      <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">person</i>
                      </div>
                      <span class="nav-link-text ms-1">Perfil</span>
                    </a>
                  </li>

                  <li class="nav-item">
                    <a class="nav-link text-white " href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                      <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="material-icons opacity-10">login</i>
                        
                      </div>
                      <span class="nav-link-text ms-1">Sair</span>
                    </a>
  
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                    style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                  </li>


                <?php endif; ?>
                
                
              

                <?php if(Auth::user()->user_type_id == 2 || Auth::user()->status == 'nao-autorizado'): ?>  
                
                <li class="nav-item">
                  <a class="nav-link text-white active bg-gradient-primary" href="<?php echo e(url('/')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                      <i class="material-icons opacity-10">dashboard</i>
                    </div>
                    <span class="nav-link-text ms-1">Início</span>
                  </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link text-white " href="<?php echo e(url('cliente.indicar.index')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                      <i class="material-icons opacity-10">settings_ethernet</i>
                    </div>
                    <span class="nav-link-text ms-1">Indicações</span>
                  </a>
                </li>


                <li class="nav-item">
                  <a class="nav-link text-white " href="<?php echo e(url('cliente.pro.favorito.index')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                      <i class="material-icons opacity-10">stars</i>
                    </div>
                    <span class="nav-link-text ms-1">Profissional Favorito</span>
                  </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link text-white " href="<?php echo e(url('perfil')); ?>">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                      <i class="material-icons opacity-10">person</i>
                    </div>
                    <span class="nav-link-text ms-1">Perfil</span>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link text-white " href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                  document.getElementById('logout-form').submit();">
                    <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
                      <i class="material-icons opacity-10">login</i>
                      
                    </div>
                    <span class="nav-link-text ms-1">Sair</span>
                  </a>

                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                  style="display: none;">
                  <?php echo csrf_field(); ?>
              </form>
                </li>
                <?php endif; ?>
          </ul>
        </div>
      </aside>
    


   
   
      <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
        
        <!-- Navbar -->
        <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
            <div class="container-fluid py-1 px-3">
              <nav aria-label="breadcrumb">
                
                <h6 class="font-weight-bolder mb-0">MEU PAINEL DE GESTÃO</h6>
              </nav>
              <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
                <div class="ms-md-auto pe-md-3 d-flex align-items-center">
                  <div class="input-group input-group-outline">
                    
                  </div>
                </div>
                <ul class="navbar-nav  justify-content-end">
                  <li class="nav-item d-flex align-items-center">
                    <a href="javascript:;" class="nav-link text-body font-weight-bold px-0">
                      <i class="fa fa-user me-sm-1"></i>
                      <span class="d-sm-inline d-none">Olá, <?php echo e(Auth::user()->name); ?></span>
                    </a>
                  </li>
                  <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
                    <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                      <div class="sidenav-toggler-inner">
                        <i class="sidenav-toggler-line"></i>
                        <i class="sidenav-toggler-line"></i>
                        <i class="sidenav-toggler-line"></i>
                      </div>
                    </a>
                  </li>
                  <li class="nav-item px-3 d-flex align-items-center">
                    <a href="javascript:;" class="nav-link text-body p-0">
                      
                    </a>
                  </li>
                  
                  
                  <li class="nav-item px-3 d-flex align-items-center" title="Sair do sistema">
                    <a class="nav-link text-body p-0" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="material-icons opacity-10">login</i>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                      style="display: none;">
                      <?php echo csrf_field(); ?>
                    </form>
                  </li>

                </ul>
              </div>
            </div>
          </nav>
          <!-- End Navbar -->


        
        
          <section class="content">

            <?php echo $__env->yieldContent('body'); ?>

        </section>


        <!-- </div>				 -->
        <footer class="footer _rodapeh">
            <div class="container-fluid">
                <nav class="copyright ml-auto">
                    <ul class="nav">
                        <li class="nav-item">
                            
                        </li>
                    </ul>
                </nav>
            </div>
        </footer>
        <!-- </div> -->
    </main>


<!-- Datatables -->
<script src="<?php echo e(asset('template/assets/js/plugin/datatables/datatables.min.js')); ?>"></script>


<script >
    $(document).ready(function() {
        $('#basic-datatables').DataTable({
        });

        $('#multi-filter-select').DataTable( {
            "pageLength": 5,
            initComplete: function () {
                this.api().columns().every( function () {
                    var column = this;
                    var select = $('<select class="form-control"><option value=""></option></select>')
                        .appendTo( $(column.footer()).empty() )
                        .on( 'change', function () {
                            var val = $.fn.dataTable.util.escapeRegex(
                                $(this).val()
                            );

                            column
                                .search( val ? '^'+val+'$' : '', true, false )
                                .draw();
                        } );

                    column.data().unique().sort().each( function ( d, j ) {
                        select.append( '<option value="'+d+'">'+d+'</option>' )
                    } );
                } );
            }
        });

        // Add Row
        $('#add-row').DataTable({
            "pageLength": 5,
        });

        var action = '<td> <div class="form-button-action"> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task"> <i class="fa fa-edit"></i> </button> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove"> <i class="fa fa-times"></i> </button> </div> </td>';

        $('#addRowButton').click(function() {
            $('#add-row').dataTable().fnAddData([
                $("#addName").val(),
                $("#addPosition").val(),
                $("#addOffice").val(),
                action
            ]);
            $('#addRowModal').modal('hide');

        });
    });
</script>

  <!--   Core JS Files   -->
  <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/chartjs.min.js')); ?>"></script>
  <script>
    var ctx = document.getElementById("chart-bars").getContext("2d");

    new Chart(ctx, {
      type: "bar",
      data: {
        labels: ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"],
        datasets: [{
          label: "Indicações",
          tension: 0.4,
          borderWidth: 0,
          borderRadius: 4,
          borderSkipped: false,
          backgroundColor: "rgba(255, 255, 255, .8)",
          data: [<?php echo e($rSegunda); ?>, 
          <?php echo e($rTerca); ?>, 
          <?php echo e($rQuarta); ?>, 
          <?php echo e($rQuinta); ?>, 
          <?php echo e($rSexta); ?>, 
          <?php echo e($rSabado); ?>, 
          <?php echo e($rDomingo); ?>],
          maxBarThickness: 6
        }, ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              suggestedMin: 0,
              suggestedMax: 500,
              beginAtZero: true,
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
              color: "#fff"
            },
          },
          x: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });


    var ctx2 = document.getElementById("chart-line").getContext("2d");

    new Chart(ctx2, {
      type: "line",
      data: {
        labels: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"],
        datasets: [{
          label: "Indicações",
          tension: 0,
          borderWidth: 0,
          pointRadius: 5,
          pointBackgroundColor: "rgba(255, 255, 255, .8)",
          pointBorderColor: "transparent",
          borderColor: "rgba(255, 255, 255, .8)",
          borderColor: "rgba(255, 255, 255, .8)",
          borderWidth: 4,
          backgroundColor: "transparent",
          fill: true,
          data: [<?php echo e($rJan); ?>, 
          <?php echo e($rFev); ?>, 
          <?php echo e($rMar); ?>, 
          <?php echo e($rAbr); ?>, 
          <?php echo e($rMai); ?>, 
          <?php echo e($rJun); ?>, 
          <?php echo e($rJul); ?>, 
          <?php echo e($rAgo); ?>, 
          <?php echo e($rSet); ?>, 
          <?php echo e($rOut); ?>, 
          <?php echo e($rNov); ?>, 
          <?php echo e($rDez); ?>],
          maxBarThickness: 6

        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });

    var ctx3 = document.getElementById("chart-line-tasks").getContext("2d");

    new Chart(ctx3, {
      type: "line",
      data: {
        labels: ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        datasets: [{
          label: "Mobile apps",
          tension: 0,
          borderWidth: 0,
          pointRadius: 5,
          pointBackgroundColor: "rgba(255, 255, 255, .8)",
          pointBorderColor: "transparent",
          borderColor: "rgba(255, 255, 255, .8)",
          borderWidth: 4,
          backgroundColor: "transparent",
          fill: true,
          data: [50, 40, 300, 220, 500, 250, 400, 230, 500],
          maxBarThickness: 6

        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              display: true,
              padding: 10,
              color: '#f8f9fa',
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });
  </script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }

    
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <script src="<?php echo e(asset('assets/js/material-dashboard.min.js?v=3.0.0')); ?>"></script>
  
  

</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/indicarFelipe/resources/views/layout/app.blade.php ENDPATH**/ ?>