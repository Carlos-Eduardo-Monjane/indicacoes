<?php $__env->startSection('content'); ?>


<?php $__env->startSection('body'); ?>
 


  
  <?php if(Auth::user()->user_type_id == 1): ?>
  
  <!--MODALS DE NEWS-->
            
            <!-- Modal editar news-->
  <?php if($msg == 'modal_edit_news'): ?>

  <div >
      <div class="modal fade" id="modalPush" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-notify modal-info" role="document">
              <!--Content-->
              <div class="modal-content text-center">
                  <!--Header-->
                  <div class="modal-header d-flex justify-content-center">
                      <h5 class="heading">
                          Edição de notícia
                      </h5>
                  </div>
                  <form action="<?php echo e(url('news.editar')); ?>/<?php echo e($new->id); ?>"  method="post" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>

                  <div class="modal-body">
                    <div class="input-group input-group-outline mb-3">
                      <input type="text" name="title" value="<?php echo e($new->title); ?>" placeholder="Título" autocomplete="off"  class="form-control">
                    </div>
                    <div class="input-group input-group-outline mb-3">
                      <textarea type="text" name="message" value="<?php echo e($new->message); ?>" placeholder="Mensagem" autocomplete="off"  class="form-control"> <?php echo e($new->message); ?></textarea>
                    </div>

                    <div class="input-group input-group-outline mb-3">
                      <input type="file" name="photo_news" value="<?php echo e($new->photo); ?>" placeholder="capa" autocomplete="off"  class="form-control">
                    </div>
                
                    <input type="hidden" name="id_news" value="<?php echo e($new->id); ?>" autocomplete="off"  class="form-control">
                  </div>
  
                  <div class="modal-footer flex-center">
                      <a type="button" id="closemodal" class="btn btn-outline-danger" data-dismiss="modal">Cancelar</a>
                      <button class="btn btn-outline-info waves-effect" type="submit" title="Confirmar">Confirmar</button>
                  </div>
                  </form>
              </div>
              <!--/.Content-->
          </div>
      </div>
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
      <script>
          $(window).on('load',function(){
              $('#modalPush').modal('show');
          });
          $('#closemodal').click(function() {
              $('#modalPush').modal('hide');
          });
      </script>
  </div>
  <?php endif; ?>
  
  
      <!-- Modal deletar news-->
<?php if($msg == 'modal_delete_news'): ?>

<div >
    <div class="modal fade" id="modalPush" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-notify modal-info" role="document">
            <!--Content-->
            <div class="modal-content text-center">
                <!--Header-->
                <div class="modal-header d-flex justify-content-center">
                    <h5 class="heading">
                        Deseja apagar <strong><?php echo e($new->title); ?></strong>?
                    </h5>
                </div>
                <form action="<?php echo e(url('news.deletar')); ?>/<?php echo e($new->id); ?>"  method="post">
                    <?php echo csrf_field(); ?>

                <div class="modal-body">
                  <p>Todos os dados relacionados serão eliminados.</p>

                  <input type="hidden" name="id_news" value="<?php echo e($new->id); ?>" autocomplete="off"  class="form-control">
                </div>

                <div class="modal-footer flex-center">
                    <a type="button" id="closemodal" class="btn btn-outline-danger" data-dismiss="modal">Cancelar</a>
                    <button class="btn btn-outline-info waves-effect" type="submit" title="Confirmar">Confirmar</button>
                </div>
                </form>
            </div>
            <!--/.Content-->
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script>
        $(window).on('load',function(){
            $('#modalPush').modal('show');
        });
        $('#closemodal').click(function() {
            $('#modalPush').modal('hide');
        });
    </script>
</div>
<?php endif; ?>


  <!-- Modal cadastrar news-->
<?php if($msg == 'modal_store_news'): ?>

 <div >
      <div class="modal fade" id="modalPush" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-notify modal-info" role="document">
              <!--Content-->
              <div class="modal-content text-center">
                  <!--Header-->
                  <div class="modal-header d-flex justify-content-center">
                    <h5 class="heading">
                        Publicar notícia
                    </h5>
                </div>
                
                
                <form action="<?php echo e(url('news.store')); ?>"  method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                <div class="modal-body">
                  <div class="input-group input-group-outline mb-3">
                    <label class="form-label">Título </label>
                    <input type="text" name="title" autocomplete="off"  class="form-control">
                  </div>
                  <div class="input-group input-group-outline mb-3">
                    <label class="form-label">Mensagem</label>
                    <textarea type="text" name="message" autocomplete="off"  class="form-control">
                        </textarea>
                  </div>
                  <div class="input-group input-group-outline mb-3">
                    <label class="form-label">Imagem de capa </label>
                    <input type="file" name="photo_news" autocomplete="off"  class="form-control">
                  </div>
                </div>

                <div class="modal-footer flex-center">
                    <a type="button" id="closemodal" class="btn btn-outline-danger" data-dismiss="modal">Cancelar</a>
                    <button class="btn btn-outline-info waves-effect" type="submit" title="Confirmar">Salvar</button>
                </div>
                </form>
                
                
                
              </div>
              <!--/.Content-->
          </div>
      </div>
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
      <script>
          $(window).on('load',function(){
              $('#modalPush').modal('show');
          });
          $('#closemodal').click(function() {
              $('#modalPush').modal('hide');
          });
      </script>
  </div>

<?php endif; ?>



  
  <!--END MODALS DE NEWS-->
  
  <!--TABELA DE NEWS-->
  <div class="container-fluid py-4">
    <div class="row">
      <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
        <div class="card">
          <div class="card-header p-3 pt-2">
            <div class="icon icon-lg icon-shape bg-gradient-dark shadow-dark text-center border-radius-xl mt-n4 position-absolute">
              <i class="material-icons opacity-10">perm_identity</i>
            </div>
            <div class="text-end pt-1">
              <p class="text-sm mb-0 text-capitalize">Total De Parceiros</p>
              <h4 class="mb-0"><?php echo e($usersParceiros); ?></h4>
            </div>
          </div>
          <hr class="dark horizontal my-0">
          <div class="card-footer p-3">
            <p class="mb-0"><span class="text-success text-sm font-weight-bolder">Com lojas</span></p>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-sm-6">
        <div class="card">
          <div class="card-header p-3 pt-2">
            <div class="icon icon-lg icon-shape bg-gradient-info shadow-info text-center border-radius-xl mt-n4 position-absolute">
              <i class="material-icons opacity-10">manage_accounts</i>
            </div>
            <div class="text-end pt-1">
              <p class="text-sm mb-0 text-capitalize">Total De Profissionais</p>
              <h4 class="mb-0"><?php echo e($usersProfissionais); ?></h4>
            </div>
          </div>
          <hr class="dark horizontal my-0">
          <div class="card-footer p-3">
            <p class="mb-0"><span class="text-success text-sm font-weight-bolder">Prontos </span></p>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
        <div class="card">
          <div class="card-header p-3 pt-2">
            <div class="icon icon-lg icon-shape bg-gradient-primary shadow-primary text-center border-radius-xl mt-n4 position-absolute">
              <i class="material-icons opacity-10">face</i>
            </div>
            <div class="text-end pt-1">
              <p class="text-sm mb-0 text-capitalize">Total De Clientes</p>
              <h4 class="mb-0"><?php echo e($usersCLientes); ?></h4>
            </div>
          </div>
          <hr class="dark horizontal my-0">
          <div class="card-footer p-3">
            <p class="mb-0"><span class="text-success text-sm font-weight-bolder">Usuários do App </span></p>
          </div>
        </div>
      </div>
      <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
        <div class="card">
          <div class="card-header p-3 pt-2">
            <div class="icon icon-lg icon-shape bg-gradient-success shadow-success text-center border-radius-xl mt-n4 position-absolute">
              <i class="material-icons me-2 text-lg">date_range</i>
            </div>
            <div class="text-end pt-1">
              <p class="text-sm mb-0 text-capitalize">Total Notícias</p>
              <h4 class="mb-0"><?php echo e($usersNoticias); ?></h4>
            </div>
          </div>
          <hr class="dark horizontal my-0">
          <div class="card-footer p-3">
            <p class="mb-0"><span class="text-success text-sm font-weight-bolder">Publicados </span></p>
          </div>
        </div>
      </div>
      
    </div>

              
          <div class="row mt-4">
            <div class="col-lg-12">
              <div class="row">
                <div class="col-md-12 mb-lg-0 mb-4">
                  <div class="card px-0 pb-2">
                      
        <?php if($msg=="success"): ?>
          <div class="alert alert-success alert-dismissible text-white" role="alert">
            <span class="text-sm">Operação feita sucesso.</span>
            <button type="button" class="btn-close text-lg py-3 opacity-10" data-bs-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <?php endif; ?>
                    <div class="card-header pb-0 px-3">
                      <div class="row">
                        <div class="col-md-6">
                          <h6 class="mb-0">Notícias</h6>
                        </div>
                        <div class="col-6 text-end">
                          <a href="<?php echo e(url('news.modal.store')); ?>" class="btn bg-gradient-dark mb-0"><i class="material-icons text-sm">add</i>&nbsp;&nbsp;Publicar nova </a>
                        </div>
                      </div>
                    </div>
                    <hr>
                    <div class="table-responsive p-0 card-body">
                      <table id="datatable-produtos" class="table align-items-center mb-0">
                        <thead>
                          <tr>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Título</th>
                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Mensagem</th>
                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Data</th>
                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Ações</th>

                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td>
                              <div class="d-flex px-2 py-1">
                                <div>
                                  <img src="<?php echo e(URL::asset('storage/'.$item->photo)); ?>" class="avatar avatar-sm me-3 border-radius-lg" alt="produto">
                              </div>
                                <div class="d-flex flex-column justify-content-center">
                                  <h6 class="mb-0 text-sm"><?php echo e($item->title); ?></h6>
                                </div>
                              </div>
                            </td>

                            <td class="align-middle text-center">
                              <span class="text-secondary text-xs font-weight-bold"><?php echo e($item->message); ?></span>
                            </td>
                                                        <td class="align-middle text-center text-sm">
                              <span class="badge badge-sm bg-gradient-success"><?php echo e($item->created_at); ?></span>
                            </td>
                            <td>
                              <a href="<?php echo e(url('news.modal.editar')); ?>/<?php echo e($item->id); ?>" class="btn btn-link text-dark px-3 mb-0" href="javascript:;"><i class="material-icons text-sm me-2" title="Editar">edit</i></a>
                              
                              
                              <a  href="<?php echo e(url('news.modal.deletar')); ?>/<?php echo e($item->id); ?>" class="btn btn-link text-danger text-gradient px-3 mb-0" ><i class="material-icons text-sm me-2" title="Apagar">delete</i></a>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>


                </div>
              </div>
            </div>

          </div>
          
  
  </div> 

  <?php endif; ?>

  
  <?php if(Auth::user()->user_type_id == 2 || Auth::user()->user_type_id == 3): ?>
        
        <?php if(Auth::user()->status == 'nao-autorizado'): ?>
            <h1>NAO AUTORIZADO</h1>

        <?php else: ?> 
        
        <div class="container-fluid py-4">
          <div class="row">

            <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
              <div class="card">
                <div class="card-header p-3 pt-2">
                  <div class="icon icon-lg icon-shape bg-gradient-primary shadow-primary text-center border-radius-xl mt-n4 position-absolute">
                    <i class="material-icons opacity-10">verified_user</i>
                  </div>
                  <div class="text-end pt-1">
                    <p class="text-sm mb-0 text-capitalize">Total NEGÓCIO FECHADO</p>
                    <h4 class="mb-0"><?php echo e($total_indicacoes_neg_fechado); ?></h4>
                  </div>
                </div>
                <hr class="dark horizontal my-0">
                <div class="card-footer p-3">
                  <p class="mb-0"><span class="text-success text-sm font-weight-bolder"> </span></p>
                </div>
              </div>
            </div>


            

            <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
              <div class="card">
                <div class="card-header p-3 pt-2">
                  <div class="icon icon-lg icon-shape bg-gradient-info shadow-info text-center border-radius-xl mt-n4 position-absolute">
                    <i class="material-icons opacity-10">blur_on</i>
                  </div>
                  <div class="text-end pt-1">
                    <p class="text-sm mb-0 text-capitalize">Total em NEGOCIAÇÃO</p>
                    <h4 class="mb-0"><?php echo e($total_indicacoes_em_negociacao); ?></h4>
                  </div>
                </div>
                <hr class="dark horizontal my-0">
                <div class="card-footer p-3">
                  <p class="mb-0"><span class="text-success text-sm font-weight-bolder"></span></p>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
              <div class="card">
                <div class="card-header p-3 pt-2">
                  <div class="icon icon-lg icon-shape bg-gradient-warning shadow-success text-center border-radius-xl mt-n4 position-absolute">
                    <i class="material-icons me-2 text-lg">blur_off</i>
                  </div>
                  <div class="text-end pt-1">
                    <p class="text-sm mb-0 text-capitalize">Total SEM CONTATO</p>
                    <h4 class="mb-0"><?php echo e($total_indicacoes_sem_contacto); ?></h4>
                  </div>
                </div>
                <hr class="dark horizontal my-0">
                <div class="card-footer p-3">
                  <p class="mb-0"><span class="text-success text-sm font-weight-bolder"> </span></p>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
              <div class="card">
                <div class="card-header p-3 pt-2">
                  <div class="icon icon-lg icon-shape bg-gradient-danger shadow-dark text-center border-radius-xl mt-n4 position-absolute">
                    <i class="material-icons opacity-10">settings_ethernet</i>
                  </div>
                  <div class="text-end pt-1">
                    <p class="text-sm mb-0 text-capitalize">Total SEM INTERESSE</p>
                    <h4 class="mb-0"><?php echo e($total_indicacoes_sem_interesse); ?></h4>
                  </div>
                </div>
                <hr class="dark horizontal my-0">
                <div class="card-footer p-3">
                  <p class="mb-0"><span class="text-success text-sm font-weight-bolder"> </span></p>
                </div>
              </div>
            </div>

            
            

  
            
          </div>
      
          <div class="row mt-4">
            <div class="col-lg-6 col-md-6 mt-4 mb-4">
              <div class="card z-index-2 ">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
                  <div class="bg-gradient-primary shadow-primary border-radius-lg py-3 pe-1">
                    <div class="chart">
                      <canvas id="chart-bars" class="chart-canvas" height="170"></canvas>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <h6 class="mb-0 ">Produção Semanal</h6>
                  <p class="text-sm ">Análise semanal das indicações </p>
                  <hr class="dark horizontal">
                  <div class="d-flex ">
                    <i class="material-icons text-sm my-auto me-1">schedule</i>
                    <p class="mb-0 text-sm"> Semana em curso... </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 mt-4 mb-4">
              <div class="card z-index-2  ">
                <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
                  <div class="bg-gradient-success shadow-success border-radius-lg py-3 pe-1">
                    <div class="chart">
                      <canvas id="chart-line" class="chart-canvas" height="170"></canvas>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <h6 class="mb-0 "> Produção Anual </h6>
                  <p class="text-sm "> Análise anual das indicações  </p>
                  <hr class="dark horizontal">
                  <div class="d-flex ">
                    <i class="material-icons text-sm my-auto me-1">schedule</i>
                    <p class="mb-0 text-sm"> Ano em curso... </p>
                  </div>
                </div>
              </div>
            </div>
            





          </div>

                       
                       
                      
      

        </div> 

        <?php endif; ?>



  <?php endif; ?>

  
  <?php if(Auth::user()->user_type_id == 4): ?>

  <?php endif; ?>


  <script>
    //datatable
      $(document).ready( function () {
          $('#datatable-conversas').DataTable();
      } );
  
      $(document).ready( function () {
          $('#datatable-categorias').DataTable();
      } );
  </script>


<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/indicarFelipe/resources/views/main.blade.php ENDPATH**/ ?>